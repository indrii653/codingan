<!--float-->
<a href="https://wa.me/+6281241855415" target="_blank" class="float">
    <i class="fa fa-whatsapp my-float"></i>
</a>
<div class="label-container">
    <div class="label-text">Daftar disini</div>
    <i class="fa fa-play label-arrow"></i>
</div>
 <!-- footer part start-->
 <footer class="footer-area">
        <div class="footer section_padding">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-xl-6 col-md-6 col-sm-6 single-footer-widget">
                        <a href="#" class="footer_logo"> <img src="<?=base_url()?>img/logo5.png" alt="#"> </a>
                    </div>
                    <div class="social_logo">
                    <h4>Media Sosial</h4>
                                    <li><a href="https://www.facebook.com/puskesmas.siliwangi.52"><i class="ti-facebook ">Puskesmas Siliwangi</i></a></li>
                                    <li><a href="https://www.instagram.com/puskesmassiliwangi/"><i class="ti-instagram">puskesmassiliwangi</i></a></li>
                                    <li><a href="https://www.youtube.com/channel/UCPNo9yb8vpnhOzxLBXUtJYw"><i class="ti-youtube">UPT PUSKESMAS SILIWANGI</i></a></li>
                    </div>
                    <div class="col-xl-3 col-sm-5 col-md-4 single-footer-widget">
                        <h4>Informasi Kami</h4>
                        <ul class="corporate-address">
                                    <li><i class="fa fa-phone" aria-hidden="true"></i><a href="Phone:(0262) 2800763">(0262) 2800763</a></li>
                                    <li><i class="fa fa-phone" aria-hidden="true"></i><a href="Phone:081241855415">+6281-2418-55415 |Layanan Pengaduan</a></li>
                                    <li><i class="fa fa-google" aria-hidden="true"></i><a href="mailto:pkmsiliwangi@gmail.com">pkmsiliwangi@gmail.com</a></li>
                                    
                        </ul>
                        
                    </div>
                   
                    <div class="col-xl-3 col-sm-6 col-md-6 single-footer-widget">
                        <div class="form-wrap" id="mc_embed_signup">
                                <div class="info"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="copyright_part">
            <div class="container">
                <div class="row align-items-center">
                    <p class="footer-text m-0 col-lg-8 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | made by <a href="https://www.smknegeri1garut.sch.id/" target="_blank">SMKN 1 GARUT</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                   
                </div>
            </div>
        </div>
    </footer>

    <!-- footer part end-->

    <!-- jquery plugins here-->

    <script src="<?=base_url()?>js/jquery-1.12.1.min.js"></script>
    <!-- popper js -->
    <script src="<?=base_url()?>js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="<?=base_url()?>js/bootstrap.min.js"></script>
    <!-- owl carousel js -->
    <script src="<?=base_url()?>js/owl.carousel.min.js"></script>
    <script src="<?=base_url()?>js/jquery.nice-select.min.js"></script>
    <!-- contact js -->
    <script src="<?=base_url()?>js/jquery.ajaxchimp.min.js"></script>
    <script src="<?=base_url()?>js/jquery.form.js"></script>
    <script src="<?=base_url()?>js/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>js/mail-script.js"></script>
    <script src="<?=base_url()?>js/contact.js"></script>
    <!-- custom js -->
    <script src="<?=base_url()?>js/custom.js"></script>
</body>

</html>