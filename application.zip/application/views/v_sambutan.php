
 <!-- banner part start-->
 <section class="banner_part">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="banner_img">
                        <img src="<?php echo base_url(); ?>img/doctor/last.png" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <div class="banner_text">
                        <div class="banner_text_iner">
                            <h1>Melayani Melebihi Harapan</h1>
                            <h4>dr. Hj. Nia Soniawaty</h4>
                            <h5>Kepala UPT Puskesmas Siliwangi</h5>                            
                            <p>Assalamu'alaikum wr.wb </p>
                            <p>Selamat datang di UPT Puskesmas Siliwangi, fasilitas kesehatan tingkat pertama milik pemerintah di Kabupaten Garut. 
                            Kami memberikan pelayanan Upaya Kesehatan Perseorangan tingkat pertama dan Upaya Kesehatan Masyarakat tingkat pertama,
                            sebagai implementasi tugas dan fungsi puskesmas sesuai dengan Peraturan Menteri Kesehatan no.43 Tahun 2019.</p>
                            <p>Dengan motto "Melayani Melebihi Harapan" dan Tata Nilai RAPIH(Ramah, Aman, Profesional, Indah, Harmonis), serta ditunjang
                                oleh sarana prasarana dan SDM yang kompeten, kami berupaya memberikan pelayanan yang bermutu, aman, dan nyaman bagi seluruh masyarakat Kabupaten Garut
                            </p>
                                </div>
                    </div>
                </div>
            </div>
        </div>
    </section>