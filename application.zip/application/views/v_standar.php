
    <!-- breadcrumb start-->
    <section class="breadcrumb_part breadcrumb_bg">
        <div class="container">
            
                <div class="col-lg-12">
                    <div class="breadcrumb_iner">
                        <div class="breadcrumb_iner_item">
                            <h2>Standar Pelayanan</h2>
                        </div>
                    </div>
                </div>
            
        </div>
    </section>
    <!-- breadcrumb stop-->
<section class="about_us single_about_padding">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-12"class="align-center ">
                  <object data="files/standar.pdf" type="application/pdf" width="1200px" height="1200px">
                  </object>
                </div>
            </div>
        </div>       
</section>