
     <section class="sec-padding">
      <div class="container">
      <div class="row">
        <div class="col-md-5">
               <div class="col-xs-12 nopadding">
                <div class="sec-title-container less-padding-5 text-left">
                  <div class="ce4-title-line-1 align-left"></div>
                  <h2 class="font-weight-7 less-mar-1">Visi</h2>
                  <h4 class="font-weight-7 less-mar-1">VISI UPT Puskesmas Siliwangi Mengikuti Visi Bupati Garut 
                    dan Dinas Kesehatan Kab.Garut, yaitu:</h4>
                  <h2 class="font-weight-7 less-mar-1">Garut yang Bertaqwa,
                    Maju dan Sejahtera</h2>
                  <div class="clearfix"></div>
                </div>
               </div>
        </div>      
        <div class="col-md-5">
               <div class="col-xs-12 nopadding">
                <div class="sec-title-container less-padding-5 text-left">
                  <div class="ce4-title-line-1 align-left"></div>
                  <h2 class="font-weight-7 less-mar-1">Misi</h2>
                  <h5 class="font-weight-7 less-mar-1">Misi UPT Puskesmas Siliwangi Mengikuti Misi Bupati Garut dan Dinas Kesehatan Kab. Garut, yaitu:</h5>
                  <dl class="font-weight-7 less-mar-1">
    <dd class="font-weight-7 less-mar-1">> Mewujudkan kualitas kehidupan masyarakat yang agamis, sehat, cerdas, dan berbudaya</dd>
    <dd class="font-weight-7 less-mar-1">> Mewujudkan pelayanan publik yang profesional dan amanah disertai tata kelola pemerintahan daerah yang baik dan bersih.</dd> 
    <dd class="font-weight-7 less-mar-1">> Mewujudkan pemerataan pembangunan yang berkeadilan serta kemantapan infrastruktur sesuai daya dukung dan daya tampung lingkungan serta fungsi ruang.</dd>
    <dd class="font-weight-7 less-mar-1">> Meningkatkan kemandirian ekonomi masyarakat berbasis potensi lokal dan industri pertanian serta pariwisata yang berdaya saing disertai pengelolaan sumber daya alam secara
berkelanjutan</dd>
  </dl> 
  <h2 class="font-weight-7 less-mar-1">Melayani Melebihi Harapan</h4>
                  <div class="clearfix"></div>
                </div>
               </div>
                
        </div> 
       

  <!-- <section class="sec-padding section-light">
      <div class="container">
      <div class="row">
        <div class="col-md-6">
               <div class="col-xs-12 nopadding">
                <div class="sec-title-container less-padding-3 text-left">
                  <div class="ce4-title-line-1 align-left"></div>
                  <h4 class="font-weight-7 less-mar-1">Motto</h4>
                  <div class="clearfix"></div>
                </div>
               </div>
                <div class="clearfix"></div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>S</strong></div>
                  <div class="text">afe</div>
                </div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>P</strong></div>
                  <div class="text">rofessional</div>
                </div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>I</strong></div>
                  <div class="text">nnovative</div>
                </div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>R</strong></div>
                  <div class="text">esponsible</div>
                </div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>I</strong></div>
                  <div class="text">ntegrated</div>
                </div>
                <div class="icons-list-1 icon-small">
                  <div class="icon icon-motto icon-circle"><strong>T</strong></div>
                  <div class="text">rustworthy</div>
                </div>
                
        </div>      
        <div class="col-md-6">  
         <div class="text-box nopadding"> 
         <img src="images/image-default.png" alt="" class="img-responsive"/>
        </div>      
        </div>
      </div>
      </div>
  </section>
  <div class="clearfix"></div> -->
    
    <section class="section-footer-rsjp sec-padding">
      <div class="container ">
        <div class="row">
          <div class="col-md-3 col-sm-12 colmargin clearfix">
            <div class="fo-map">
                <div class="footer-logo"></div>
            </div>
          </div>
          <div class="col-md-3 col-sm-12 colmargin clearfix">
            <span>
          </div>
      </div>
      </div>
    </section>